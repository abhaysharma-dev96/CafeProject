import React from 'react';
import { motion } from 'framer-motion';
import { Calendar, Clock, Users, MapPin } from 'lucide-react';

const Reservations = () => {
  return (
    <div className="pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-20">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-headline-lg text-6xl text-primary mb-6"
          >
            Join Us at the Hearth
          </motion.h1>
          <p className="text-secondary max-w-xl mx-auto">Reserve a table for a curated coffee experience or reach out with any inquiries.</p>
        </header>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Reservation Form */}
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.2 }}
            className="bg-white p-10 rounded-[40px] shadow-sm border border-primary/5"
          >
            <div className="flex items-center gap-3 mb-8">
              <Calendar className="text-primary" />
              <h2 className="font-headline-md text-3xl text-primary">Reserve a Table</h2>
            </div>

            <form className="space-y-8">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-secondary/60 ml-1">Date</label>
                  <input type="date" className="w-full bg-surface p-4 rounded-2xl border border-primary/5 outline-none focus:ring-2 focus:ring-primary/10" />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-secondary/60 ml-1">Time</label>
                  <select className="w-full bg-surface p-4 rounded-2xl border border-primary/5 outline-none focus:ring-2 focus:ring-primary/10">
                    <option>Select Time</option>
                    <option>08:00 AM</option>
                    <option>10:00 AM</option>
                    <option>02:00 PM</option>
                  </select>
                </div>
              </div>

              <div className="space-y-4">
                <label className="text-xs font-bold uppercase tracking-widest text-secondary/60 ml-1">Party Size</label>
                <div className="flex gap-4">
                  {[1, 2, 3, 4, '5+'].map((n) => (
                    <button key={n} type="button" className={`w-12 h-12 rounded-full border border-primary/10 flex items-center justify-center font-bold transition-all ${n === 2 ? 'bg-primary text-white scale-110' : 'hover:bg-primary/5'}`}>
                      {n}
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-secondary/60 ml-1">Special Requests</label>
                <textarea rows="4" className="w-full bg-surface p-4 rounded-2xl border border-primary/5 outline-none focus:ring-2 focus:ring-primary/10" placeholder="e.g. Window seat, dietary restrictions..."></textarea>
              </div>

              <button className="w-full bg-primary text-white py-5 rounded-2xl font-bold hover:shadow-xl active:scale-[0.98] transition-all">
                Confirm Reservation
              </button>
            </form>
          </motion.div>

          {/* Contact Section */}
          <div className="space-y-12">
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.4 }}
              className="bg-surface-container-low p-10 rounded-[40px]"
            >
              <h3 className="font-headline-md text-3xl text-primary mb-8">Get in Touch</h3>
              <div className="space-y-6">
                <input type="text" placeholder="Your Name" className="w-full bg-white p-4 rounded-2xl outline-none focus:ring-2 focus:ring-primary/10" />
                <input type="email" placeholder="Email Address" className="w-full bg-white p-4 rounded-2xl outline-none focus:ring-2 focus:ring-primary/10" />
                <textarea placeholder="Your Message" rows="4" className="w-full bg-white p-4 rounded-2xl outline-none focus:ring-2 focus:ring-primary/10"></textarea>
                <button className="w-full border border-primary text-primary py-4 rounded-2xl font-bold hover:bg-primary/5 transition-all">
                  Send Message
                </button>
              </div>
            </motion.div>

            {/* Map Preview */}
            <motion.div 
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.6 }}
              className="rounded-[40px] overflow-hidden aspect-video relative group"
            >
              <img src="https://images.unsplash.com/photo-1524661135-423995f22d0b?auto=format&fit=crop&q=80&w=800" alt="Map" className="w-full h-full object-cover" />
              <div className="absolute inset-0 bg-primary/20 group-hover:bg-primary/10 transition-colors" />
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-white px-6 py-4 rounded-full shadow-2xl flex items-center gap-2">
                <MapPin className="text-primary" size={20} />
                <span className="font-bold text-primary">Find Us</span>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reservations;
