import React from 'react';
import { motion } from 'framer-motion';

const Home = () => {
  return (
    <div className="overflow-hidden">
      {/* Hero */}
      <section className="min-h-screen relative flex items-center justify-center pt-20">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-surface via-transparent to-surface z-10" />
          <img 
            src="https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=2000" 
            alt="Coffee" 
            className="w-full h-full object-cover opacity-30"
          />
        </div>
        
        <div className="relative z-10 text-center max-w-4xl px-6">
          <motion.h1 
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="font-headline-lg text-6xl md:text-8xl text-primary mb-8"
          >
            Crafting Moments, One Brew at a Time
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-secondary text-xl mb-12 max-w-2xl mx-auto"
          >
            Experience the harmony of artisanal roasting and mindful spaces. A warm minimalist haven for coffee enthusiasts.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="flex flex-col sm:flex-row gap-6 justify-center"
          >
            <button className="bg-primary text-white px-10 py-4 rounded-full font-bold hover:shadow-xl transition-all">
              View Menu
            </button>
            <button className="border border-primary text-primary px-10 py-4 rounded-full font-bold hover:bg-primary/5 transition-all">
              Reserve Table
            </button>
          </motion.div>
        </div>
      </section>

      {/* Featured Items */}
      <section className="py-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-20">
            <h2 className="font-headline-md text-4xl text-primary mb-4">Signature Serves</h2>
            <p className="text-secondary">Curated experiences in every cup.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-12">
            {[
              { name: 'Lavender Latte', price: '$6.50', image: 'https://images.unsplash.com/photo-1572286258217-40142c1c6a70?auto=format&fit=crop&q=80&w=600' },
              { name: 'Smoked Mocha', price: '$7.00', image: 'https://images.unsplash.com/photo-1541167760496-162955ed8a9f?auto=format&fit=crop&q=80&w=600' },
              { name: 'Matcha Rose', price: '$6.50', image: 'https://images.unsplash.com/photo-1515823064-d6e0c04616a7?auto=format&fit=crop&q=80&w=600' }
            ].map((item, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: i * 0.1 }}
                className="group cursor-pointer"
              >
                <div className="aspect-[4/5] overflow-hidden rounded-3xl mb-6 shadow-sm">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700" />
                </div>
                <div className="flex justify-between items-center px-2">
                  <div>
                    <h3 className="font-headline-md text-2xl text-primary">{item.name}</h3>
                    <p className="text-secondary/60 text-sm">Artisanal Brew & Hearth</p>
                  </div>
                  <span className="bg-primary/5 text-primary px-4 py-1 rounded-full font-bold">{item.price}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-32 bg-surface-container-low px-6">
        <div className="max-w-7xl mx-auto grid md:grid-cols-2 gap-20 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="rounded-[40px] overflow-hidden shadow-2xl"
          >
            <img src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?auto=format&fit=crop&q=80&w=800" alt="Cafe Interior" />
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-primary/60 font-bold tracking-widest text-sm uppercase mb-4 block">Our Story</span>
            <h2 className="font-headline-md text-5xl text-primary mb-8 leading-tight">Rooted in Craft, Designed for Connection</h2>
            <p className="text-secondary text-lg mb-10 leading-relaxed">
              Brew & Hearth was born from a simple desire: to create a space that feels like a deep breath. We believe coffee is more than a beverage; it's a ritual, a pause in the momentum of the day.
            </p>
            <button className="flex items-center gap-2 font-bold text-primary group">
              Read Our Manifesto <span className="group-hover:translate-x-2 transition-transform">→</span>
            </button>
          </motion.div>
        </div>
      </section>
    </div>
  );
};

export default Home;
