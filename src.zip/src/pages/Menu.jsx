import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, SlidersHorizontal, Plus, Minus } from 'lucide-react';

const Menu = () => {
  const [activeTab, setActiveTab] = useState('Coffee');
  const categories = ['Coffee', 'Tea', 'Snacks', 'Desserts'];

  const menuItems = [
    { name: 'Pour Over', price: '$6.50', category: 'Coffee', desc: 'Single-origin Ethiopian Yirgacheffe, meticulously hand-poured.', tags: ['Floral', 'Citrus'], image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?auto=format&fit=crop&q=80&w=600' },
    { name: 'Iced Flat White', price: '$5.50', category: 'Coffee', desc: 'Our signature house blend espresso pulled over cold milk and ice.', tags: ['Smooth', 'Bold'], image: 'https://images.unsplash.com/photo-1517701604599-bb29b565090c?auto=format&fit=crop&q=80&w=600' },
    { name: 'Almond Croissant', price: '$4.75', category: 'Snacks', desc: 'Twice-baked butter croissant filled with rich frangipane.', tags: ['Nutty', 'Flaky'], image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&q=80&w=600' }
  ];

  return (
    <div className="pt-32 pb-20 px-6">
      <div className="max-w-7xl mx-auto">
        <header className="text-center mb-20">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="font-headline-lg text-6xl text-primary mb-6"
          >
            Our Menu
          </motion.h1>
          <p className="text-secondary max-w-xl mx-auto">Sourced globally, crafted locally. Explore our selection of artisanal beverages.</p>
        </header>

        {/* Filter Bar */}
        <div className="flex flex-col md:flex-row justify-between items-center gap-8 mb-16">
          <div className="flex gap-8 border-b border-primary/10 w-full md:w-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveTab(cat)}
                className={`pb-4 px-2 relative transition-all ${activeTab === cat ? 'text-primary font-bold' : 'text-secondary hover:text-primary'}`}
              >
                {cat}
                {activeTab === cat && (
                  <motion.div layoutId="activeTab" className="absolute bottom-0 left-0 w-full h-0.5 bg-primary" />
                )}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-secondary/40" size={18} />
              <input 
                type="text" 
                placeholder="Search menu..." 
                className="w-full pl-12 pr-4 py-3 bg-white rounded-full border border-primary/10 focus:ring-2 focus:ring-primary/20 outline-none transition-all"
              />
            </div>
            <button className="p-3 border border-primary/10 rounded-full text-secondary hover:bg-primary/5 transition-all">
              <SlidersHorizontal size={20} />
            </button>
          </div>
        </div>

        {/* Menu Grid */}
        <motion.div 
          layout
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8"
        >
          <AnimatePresence mode="popLayout">
            {menuItems.filter(item => item.category === activeTab || activeTab === 'All').map((item, i) => (
              <motion.div
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4 }}
                key={item.name}
                className="bg-white rounded-[32px] p-4 shadow-sm border border-primary/5 group"
              >
                <div className="aspect-video rounded-2xl overflow-hidden mb-6">
                  <img src={item.image} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="px-2">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="font-headline-md text-2xl text-primary">{item.name}</h3>
                    <span className="font-bold text-primary">{item.price}</span>
                  </div>
                  <p className="text-secondary/70 text-sm mb-6 leading-relaxed">{item.desc}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex gap-2">
                      {item.tags.map(tag => (
                        <span key={tag} className="text-[10px] uppercase tracking-wider font-bold bg-secondary-container/30 text-secondary px-3 py-1 rounded-full">{tag}</span>
                      ))}
                    </div>
                    <div className="flex items-center gap-3 bg-surface p-1 rounded-full border border-primary/5">
                      <button className="p-1 hover:text-primary transition-colors"><Minus size={16} /></button>
                      <span className="text-sm font-bold w-4 text-center">1</span>
                      <button className="p-1 bg-primary text-white rounded-full hover:scale-110 transition-transform"><Plus size={16} /></button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
      </div>
    </div>
  );
};

export default Menu;
