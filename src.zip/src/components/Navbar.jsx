import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Home', path: '/' },
    { name: 'Menu', path: '/menu' },
    { name: 'About', path: '/about' },
    { name: 'Gallery', path: '/gallery' },
    { name: 'Reservations', path: '/reservations' },
  ];

  return (
    <nav className={`fixed top-0 w-full z-50 transition-all duration-300 ${isScrolled ? 'bg-surface/80 backdrop-blur-xl border-b border-primary/10 py-4 shadow-sm' : 'bg-transparent py-6'}`}>
      <div className="max-w-screen-2xl mx-auto px-6 md:px-12 flex justify-between items-center">
        <Link to="/" className="font-headline-md text-2xl font-bold text-primary tracking-tight">
          Brew & Hearth
        </Link>

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <Link
              key={link.name}
              to={link.path}
              className={`font-body-md text-sm tracking-wide transition-all relative py-1 ${location.pathname === link.path ? 'text-primary font-bold' : 'text-secondary hover:text-primary'}`}
            >
              {link.name}
              {location.pathname === link.path && (
                <motion.div layoutId="navUnderline" className="absolute bottom-0 left-0 w-full h-0.5 bg-primary" />
              )}
            </Link>
          ))}
          <button className="p-2 hover:scale-110 transition-transform text-primary relative">
            <ShoppingBag size={20} />
            <span className="absolute -top-1 -right-1 bg-primary text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center">0</span>
          </button>
        </div>

        {/* Mobile Toggle */}
        <div className="md:hidden flex items-center gap-4">
          <button className="p-2 text-primary">
            <ShoppingBag size={20} />
          </button>
          <button onClick={() => setIsMobileMenuOpen(true)} className="p-2 text-primary">
            <Menu size={24} />
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 bg-surface z-[60] flex flex-col p-8"
          >
            <div className="flex justify-between items-center mb-12">
              <span className="font-headline-md text-2xl font-bold text-primary">Brew & Hearth</span>
              <button onClick={() => setIsMobileMenuOpen(false)} className="p-2 text-primary">
                <X size={28} />
              </button>
            </div>
            <div className="flex flex-col gap-8">
              {navLinks.map((link) => (
                <Link
                  key={link.name}
                  to={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={`text-3xl font-headline-md ${location.pathname === link.path ? 'text-primary font-bold' : 'text-secondary'}`}
                >
                  {link.name}
                </Link>
              ))}
            </div>
            <div className="mt-auto pt-12 border-t border-primary/10">
              <Link to="/reservations" onClick={() => setIsMobileMenuOpen(false)} className="w-full bg-primary text-white py-4 rounded-full flex justify-center items-center font-bold">
                Reserve a Table
              </Link>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;
